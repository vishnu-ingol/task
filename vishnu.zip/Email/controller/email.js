

const Sequelize = require("sequelize");
const db = require('../models/index');
const Email= db.email;
let nodemailer = require('nodemailer');
let cron = require('node-cron');
exports.create = (req, res) => {
  // Create a Email
  const email = {
    s_id:req.body.s_id,
    to: req.body.to,
    subject: req.body.subject,
    text: req.body.text,
    schedule_time: req.body.schedule_time
  };

  // Save  in the database
  Email.create(email)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while creating the Tutorial."
      });
    });
};

exports.update = async (req, res) => {
  try {
    const { s_id } = req.params;
    const [ updated ] = await Email.update(req.body, {
      where: { s_id:s_id}
    });
    if (updated) {
      const updatedPost = await Email.update({ where: { s_id:s_id } });
      return res.status(200).json({ post: updatedPost });
    }
    throw new Error('Post not found');
  } catch (error) {
    return res.status(500).send(error.message);
  }
};

exports.getEmail = async (req, res) => {
    const Result = await Customer.findAll()
    if(Result){
      res.json({
        data:Result,
      })
    } 
}

exports.sendEmail = (req, res) => {
  const data = await Email.update({ where: { s_id:s_id } });
  let mailOptions = {
    from: 'vishnuingole1994@gamil.com',
    to: data.to,
    subject: data.subject,
    text: data.text
  };
  
  let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'vishnuingole1994@gmail.com',
      pass: '**************'
    }
  });
  cron.schedule(data.schedule_time, () => {
    transporter.sendMail(mailOptions, function(error, info){
          if (error) {
            console.log(error);
          } else {
            console.log('Email sent: ' + info.response);
          }
      });
    });
  
};
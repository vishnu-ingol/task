
    
    const email = require('../controller/email')
    var router = require("express").Router();
    router.post("/email", email.create);
    router.put("/email", email.update);
    router.get("/post", email.getEmail);
    router.post("/schedule-email-send", email.sendEmail);

module.exports =router;

module.exports = (sequelize, Sequelize) => {
  const Order = sequelize.define('email', {
    s_id: {
      type: Sequelize.INTEGER,
    },
    to: {
      type: Sequelize.INTEGER,
    },
    subject: {
      type: Sequelize.STRING,

    },
    text: {
      type: Sequelize.STRING,
    },
    schedule_time: {
      type: Sequelize.STRING
    }

  });

  return Order;
}
